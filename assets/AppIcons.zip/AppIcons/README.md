# Bộ icon ứng dụng — App cho vay / thanh toán

Thiết kế: đồng tiền (ký hiệu **$**) được **bàn tay khum đỡ/nắm**, nền **đỏ gradient** (#EE3742 → #C20E27), hình **trắng**.

## Cấu trúc thư mục

```
AppIcons/
├── iOS/
│   └── AppIcon.appiconset/      ← Kéo nguyên thư mục này vào Xcode
│       ├── Contents.json
│       └── Icon-*.png            (đã bỏ alpha, đúng chuẩn App Store)
├── Android/
│   ├── res/
│   │   ├── mipmap-mdpi/ … mipmap-xxxhdpi/
│   │   │   ├── ic_launcher.png            (icon vuông bo góc – legacy)
│   │   │   ├── ic_launcher_round.png      (icon tròn – legacy)
│   │   │   ├── ic_launcher_foreground.png (lớp trước – adaptive)
│   │   │   └── ic_launcher_background.png (lớp nền – adaptive)
│   │   └── mipmap-anydpi-v26/
│   │       ├── ic_launcher.xml            (adaptive icon, API 26+)
│   │       └── ic_launcher_round.xml
│   └── play_store/
│       └── ic_launcher-playstore-512.png  (icon 512×512 cho Google Play Console)
└── _master/
    ├── icon_square_1024.png      (bản vuông gốc)
    ├── icon_rounded_1024.png     (bản bo góc – để xem/marketing)
    └── logo_transparent_1024.png (logo nền trong suốt)
```

## Cách dùng

### iOS (Xcode)
1. Mở `Assets.xcassets` trong Xcode.
2. Xoá `AppIcon` cũ (nếu có), kéo thả thư mục **`AppIcon.appiconset`** vào.
3. Build — icon hiển thị đầy đủ mọi kích thước iPhone/iPad + App Store 1024.
   *(Các file iOS đã ở chế độ RGB, không có kênh alpha, nên không bị App Store từ chối.)*

### Android (Android Studio)
1. Copy nội dung thư mục **`Android/res/`** vào `app/src/main/res/` của dự án (gộp các thư mục `mipmap-*`).
2. Trong `AndroidManifest.xml`, đảm bảo:
   ```xml
   <application
       android:icon="@mipmap/ic_launcher"
       android:roundIcon="@mipmap/ic_launcher_round" ... >
   ```
3. Máy Android 8.0+ (API 26+) sẽ tự dùng **adaptive icon** (foreground + background) theo hình dạng của từng launcher.

### Google Play Console
- Tải `Android/play_store/ic_launcher-playstore-512.png` lên mục **App icon** (512×512).

### App Store Connect
- Icon 1024×1024 đã nằm sẵn trong appiconset; Xcode tự nộp khi upload build.

## Đổi ký hiệu tiền tệ
Logo đang dùng "$". Nếu muốn đổi sang **₫** (đồng) hoặc ký hiệu khác, có thể tạo lại từ file SVG gốc — chỉ cần báo mình.
